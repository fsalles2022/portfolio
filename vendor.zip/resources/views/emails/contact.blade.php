<h1>Contato de {{ $name }}</h1>
<p>{{ $body }}</p><br />
<br />
Endereço de email: {{ $email }}
