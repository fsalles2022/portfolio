<template>
  <div class="bg-orange-300 dark:bg-dark-navy-500">
    <div
      class="
        container
        mx-auto
        py-12
        px-4
        sm:px-6
        lg:flex lg:items-center lg:justify-between lg:py-16 lg:px-8
      "
    >
      <h2
        class="
          text-3xl
          font-bold
          tracking-tight
          text-light-tail-500
          dark:text-dark-navy-100
          sm:text-4xl
        "
      >
        <span class="block">Pronto para desenvolver?</span>
        <span class="block text-dark-primary dark:text-white">Desenvolvimento! Acompanhamos as mudanças com a velocidade e eficiência que a Web exige.</span
        >
      </h2>
      <div class="mt-8 flex lg:mt-0 lg:flex-shrink-0">
        <div class="inline-flex rounded-md shadow">
          <a
            href="#contact"
            class="
              inline-flex
              items-center
              justify-center
              rounded-md
              border border-transparent
              bg-light-secondary
              dark:bg-dark-secondary
              px-5
              py-3
              text-base
              font-medium
              text-dark-primary
              dark:text-white
              hover:bg-light-primary
              dark:hover:bg-dark-primary
            "
            >Bora começar?</a
          >
        </div>
      </div>
      
    </div>
    
  </div>
</template>