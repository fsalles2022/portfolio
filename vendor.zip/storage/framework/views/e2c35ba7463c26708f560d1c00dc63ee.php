<h1>Contato de <?php echo e($name); ?></h1>
<p><?php echo e($body); ?></p><br />
<br />
Endereço de email: <?php echo e($email); ?>

<?php /**PATH C:\laragon\www\portfolio\resources\views/emails/contact.blade.php ENDPATH**/ ?>